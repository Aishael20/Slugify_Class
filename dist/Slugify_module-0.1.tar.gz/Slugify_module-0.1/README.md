Pour utiliser ce package vous devez l'installer avec la commande pip install <nom_package> puis l'importer dans le fichier où vous souhaitez l'utiliser.Veuillez noter que pip doit être déjà installé sur votre ordinateur pour faire cette opération.

N'oubliez pas ce package vous permettra de convertir une chaine de caractères en Slug.

----------------------------------------------------------------------------------------------------------------------------------------

To use this package, you need to install it with the pip install <package_name> command, then import it into the file you wish to use it in. Please note that you must already have pip installed on your computer to do this.

Don't forget this package will allow you to convert a string into a Slug.
